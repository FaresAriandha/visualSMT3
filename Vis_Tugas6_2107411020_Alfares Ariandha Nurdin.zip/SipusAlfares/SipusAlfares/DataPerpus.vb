﻿Public Class DataPerpus
    Private namaKoleksi
    Private jenisKoleksi
    Private deskripsi
    Private penerbit
    Private tahunTerbit
    Private rakBuku
    Private tglMasuk
    Private stok
    Private bahasa
    Private infoKategori As New List(Of String)
    Private listKoleksi As New List(Of String)
    Private fotoKoleksi


    Public Property GSnamaKoleksi() As String
        Get
            Return namaKoleksi
        End Get
        Set(ByVal value As String)
            namaKoleksi = value
        End Set
    End Property

    Public Property GSjenisKoleksi() As String
        Get
            Return jenisKoleksi
        End Get
        Set(ByVal value As String)
            jenisKoleksi = value
        End Set
    End Property

    Public Property GSdeskripsiKoleksi() As String
        Get
            Return deskripsi
        End Get
        Set(ByVal value As String)
            deskripsi = value
        End Set
    End Property

    Public Property GSpenerbit() As String
        Get
            Return penerbit
        End Get
        Set(ByVal value As String)
            penerbit = value
        End Set
    End Property

    Public Property GStahun() As String
        Get
            Return tahunTerbit
        End Get
        Set(ByVal value As String)
            tahunTerbit = value
        End Set
    End Property

    Public Property GSrakBuku() As String
        Get
            Return rakBuku
        End Get
        Set(ByVal value As String)
            rakBuku = value
        End Set
    End Property


    Public Property GStglMasuk() As String
        Get
            Return tglMasuk
        End Get
        Set(ByVal value As String)
            tglMasuk = value
        End Set
    End Property


    Public Property GSstok() As String
        Get
            Return stok
        End Get
        Set(ByVal value As String)
            stok = value
        End Set
    End Property

    Public Property GSbahasa() As String
        Get
            Return bahasa
        End Get
        Set(ByVal value As String)
            bahasa = value
        End Set
    End Property

    Public ReadOnly Property GSinfoKategori() As List(Of String)
        Get
            Return infoKategori
        End Get
    End Property

    Public ReadOnly Property GSlistKoleksi() As List(Of String)
        Get
            Return listKoleksi
        End Get
    End Property

    Public Property GSfoto() As String
        Get
            Return fotoKoleksi
        End Get
        Set(ByVal value As String)
            fotoKoleksi = value
        End Set
    End Property

End Class
