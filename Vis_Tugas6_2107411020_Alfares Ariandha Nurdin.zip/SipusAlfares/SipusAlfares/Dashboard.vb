﻿Public Class Dashboard
    Public Shared dataPerpus As DataPerpus
    Public Shared selectedCollection As String

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        dataPerpus = New DataPerpus()

    End Sub


    Private Sub TambahKoleksiToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TambahKoleksiToolStripMenuItem.Click
        TambahKoleksi.Show()
    End Sub

    Private Sub BtnShowFormAddKoleksi_Click(sender As Object, e As EventArgs) Handles BtnShowFormAddKoleksi.Click
        TambahKoleksi.Show()
    End Sub

    Private Sub Dashboard_Activated(sender As Object, e As EventArgs) Handles Me.Activated
        For Each kel In dataPerpus.GSlistKoleksi
            ListBoxKoleksi.Items.Add(kel)
        Next
        dataPerpus.GSlistKoleksi.Clear()
    End Sub

    Private Sub BtnShowFormDelKoleksi_Click(sender As Object, e As EventArgs) Handles BtnShowFormDelKoleksi.Click

        selectedCollection = ListBoxKoleksi.SelectedItem()
        If selectedCollection IsNot Nothing Then
            HapusKoleksi.Show()
        Else
            MsgBox("Harap Pilih Koleksi", MsgBoxStyle.Critical, "Kesalahan")

        End If

    End Sub

    Public Sub procHapus(item As String)
        dataPerpus.GSlistKoleksi.Remove(item)
        ListBoxKoleksi.Items.Remove(item)
    End Sub


    'List Getter and Setter

End Class
