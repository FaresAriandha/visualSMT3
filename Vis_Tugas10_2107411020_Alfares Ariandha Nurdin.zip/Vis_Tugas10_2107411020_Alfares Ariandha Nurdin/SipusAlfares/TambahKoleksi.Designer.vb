﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TambahKoleksi
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PcbKoleksi = New System.Windows.Forms.PictureBox()
        Me.BtnAddImage = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TxtBoxNama = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.CBJenisKoleksi = New System.Windows.Forms.ComboBox()
        Me.RTBdesc = New System.Windows.Forms.RichTextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TxtBoxPenerbit = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TxtBoxTahun = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TxtBoxLocRak = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.DatePickTglMasuk = New System.Windows.Forms.DateTimePicker()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.TxtBoxStock = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.RBEnglish = New System.Windows.Forms.RadioButton()
        Me.RBIndonesian = New System.Windows.Forms.RadioButton()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.BtnAddKoleksi = New System.Windows.Forms.Button()
        Me.CBSains = New System.Windows.Forms.CheckBox()
        Me.CBSosial = New System.Windows.Forms.CheckBox()
        Me.CBTeknologi = New System.Windows.Forms.CheckBox()
        Me.CBBudaya = New System.Windows.Forms.CheckBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        CType(Me.PcbKoleksi, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'PcbKoleksi
        '
        Me.PcbKoleksi.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.PcbKoleksi.ErrorImage = Nothing
        Me.PcbKoleksi.InitialImage = Nothing
        Me.PcbKoleksi.Location = New System.Drawing.Point(28, 81)
        Me.PcbKoleksi.Name = "PcbKoleksi"
        Me.PcbKoleksi.Size = New System.Drawing.Size(177, 194)
        Me.PcbKoleksi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PcbKoleksi.TabIndex = 0
        Me.PcbKoleksi.TabStop = False
        '
        'BtnAddImage
        '
        Me.BtnAddImage.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.BtnAddImage.Location = New System.Drawing.Point(28, 287)
        Me.BtnAddImage.Name = "BtnAddImage"
        Me.BtnAddImage.Size = New System.Drawing.Size(177, 39)
        Me.BtnAddImage.TabIndex = 1
        Me.BtnAddImage.Text = "Tambah Gambar"
        Me.BtnAddImage.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label1.Location = New System.Drawing.Point(28, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(177, 36)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Tambah Koleksi"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label2.Location = New System.Drawing.Point(244, 81)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(112, 25)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Nama Koleksi"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label3.Location = New System.Drawing.Point(460, 81)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(17, 25)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = ":"
        '
        'TxtBoxNama
        '
        Me.TxtBoxNama.Location = New System.Drawing.Point(483, 81)
        Me.TxtBoxNama.Name = "TxtBoxNama"
        Me.TxtBoxNama.Size = New System.Drawing.Size(203, 27)
        Me.TxtBoxNama.TabIndex = 5
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label4.Location = New System.Drawing.Point(460, 127)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(17, 25)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = ":"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label5.Location = New System.Drawing.Point(244, 127)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(105, 25)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Jenis Koleksi"
        '
        'CBJenisKoleksi
        '
        Me.CBJenisKoleksi.FormattingEnabled = True
        Me.CBJenisKoleksi.Items.AddRange(New Object() {"History", "Fiction", "Fantasy", "Mathematic"})
        Me.CBJenisKoleksi.Location = New System.Drawing.Point(485, 128)
        Me.CBJenisKoleksi.Name = "CBJenisKoleksi"
        Me.CBJenisKoleksi.Size = New System.Drawing.Size(199, 28)
        Me.CBJenisKoleksi.TabIndex = 8
        Me.CBJenisKoleksi.Text = "--Pilih Jenis--"
        '
        'RTBdesc
        '
        Me.RTBdesc.Location = New System.Drawing.Point(483, 181)
        Me.RTBdesc.Name = "RTBdesc"
        Me.RTBdesc.Size = New System.Drawing.Size(200, 119)
        Me.RTBdesc.TabIndex = 9
        Me.RTBdesc.Text = ""
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label6.Location = New System.Drawing.Point(460, 181)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(17, 25)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = ":"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label7.Location = New System.Drawing.Point(244, 181)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(80, 25)
        Me.Label7.TabIndex = 10
        Me.Label7.Text = "Deskripsi"
        '
        'TxtBoxPenerbit
        '
        Me.TxtBoxPenerbit.Location = New System.Drawing.Point(480, 333)
        Me.TxtBoxPenerbit.Name = "TxtBoxPenerbit"
        Me.TxtBoxPenerbit.Size = New System.Drawing.Size(203, 27)
        Me.TxtBoxPenerbit.TabIndex = 14
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label8.Location = New System.Drawing.Point(457, 333)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(17, 25)
        Me.Label8.TabIndex = 13
        Me.Label8.Text = ":"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label9.Location = New System.Drawing.Point(241, 333)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(73, 25)
        Me.Label9.TabIndex = 12
        Me.Label9.Text = "Penerbit"
        '
        'TxtBoxTahun
        '
        Me.TxtBoxTahun.Location = New System.Drawing.Point(480, 375)
        Me.TxtBoxTahun.Name = "TxtBoxTahun"
        Me.TxtBoxTahun.Size = New System.Drawing.Size(203, 27)
        Me.TxtBoxTahun.TabIndex = 17
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label10.Location = New System.Drawing.Point(457, 375)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(17, 25)
        Me.Label10.TabIndex = 16
        Me.Label10.Text = ":"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label11.Location = New System.Drawing.Point(241, 375)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(101, 25)
        Me.Label11.TabIndex = 15
        Me.Label11.Text = "Tahun Terbit"
        '
        'TxtBoxLocRak
        '
        Me.TxtBoxLocRak.Location = New System.Drawing.Point(480, 421)
        Me.TxtBoxLocRak.Name = "TxtBoxLocRak"
        Me.TxtBoxLocRak.Size = New System.Drawing.Size(203, 27)
        Me.TxtBoxLocRak.TabIndex = 20
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label12.Location = New System.Drawing.Point(457, 421)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(17, 25)
        Me.Label12.TabIndex = 19
        Me.Label12.Text = ":"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label13.Location = New System.Drawing.Point(241, 421)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(92, 25)
        Me.Label13.TabIndex = 18
        Me.Label13.Text = "Lokasi Rak"
        '
        'DatePickTglMasuk
        '
        Me.DatePickTglMasuk.Location = New System.Drawing.Point(480, 475)
        Me.DatePickTglMasuk.Name = "DatePickTglMasuk"
        Me.DatePickTglMasuk.Size = New System.Drawing.Size(204, 27)
        Me.DatePickTglMasuk.TabIndex = 21
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label14.Location = New System.Drawing.Point(457, 475)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(17, 25)
        Me.Label14.TabIndex = 23
        Me.Label14.Text = ":"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label15.Location = New System.Drawing.Point(241, 475)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(179, 25)
        Me.Label15.TabIndex = 22
        Me.Label15.Text = "Tanggal Masuk Koleksi"
        '
        'TxtBoxStock
        '
        Me.TxtBoxStock.Location = New System.Drawing.Point(480, 524)
        Me.TxtBoxStock.Name = "TxtBoxStock"
        Me.TxtBoxStock.Size = New System.Drawing.Size(203, 27)
        Me.TxtBoxStock.TabIndex = 26
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label16.Location = New System.Drawing.Point(457, 524)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(17, 25)
        Me.Label16.TabIndex = 25
        Me.Label16.Text = ":"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label17.Location = New System.Drawing.Point(241, 524)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(45, 25)
        Me.Label17.TabIndex = 24
        Me.Label17.Text = "Stok"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label18.Location = New System.Drawing.Point(807, 83)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(17, 25)
        Me.Label18.TabIndex = 28
        Me.Label18.Text = ":"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label19.Location = New System.Drawing.Point(734, 81)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(67, 25)
        Me.Label19.TabIndex = 27
        Me.Label19.Text = "Bahasa"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.GroupBox1.Controls.Add(Me.RBEnglish)
        Me.GroupBox1.Controls.Add(Me.RBIndonesian)
        Me.GroupBox1.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.GroupBox1.Location = New System.Drawing.Point(849, 83)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(250, 125)
        Me.GroupBox1.TabIndex = 29
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Bahasa"
        '
        'RBEnglish
        '
        Me.RBEnglish.AutoSize = True
        Me.RBEnglish.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.RBEnglish.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.RBEnglish.Location = New System.Drawing.Point(22, 74)
        Me.RBEnglish.Name = "RBEnglish"
        Me.RBEnglish.Size = New System.Drawing.Size(141, 29)
        Me.RBEnglish.TabIndex = 1
        Me.RBEnglish.TabStop = True
        Me.RBEnglish.Text = "Bahasa Inggris"
        Me.RBEnglish.UseVisualStyleBackColor = True
        '
        'RBIndonesian
        '
        Me.RBIndonesian.AutoSize = True
        Me.RBIndonesian.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.RBIndonesian.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.RBIndonesian.Location = New System.Drawing.Point(22, 44)
        Me.RBIndonesian.Name = "RBIndonesian"
        Me.RBIndonesian.Size = New System.Drawing.Size(164, 29)
        Me.RBIndonesian.TabIndex = 0
        Me.RBIndonesian.TabStop = True
        Me.RBIndonesian.Text = "Bahasa Indonesia"
        Me.RBIndonesian.UseVisualStyleBackColor = True
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label20.Location = New System.Drawing.Point(807, 242)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(17, 25)
        Me.Label20.TabIndex = 31
        Me.Label20.Text = ":"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label21.Location = New System.Drawing.Point(734, 240)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(72, 25)
        Me.Label21.TabIndex = 30
        Me.Label21.Text = "Kategori"
        '
        'BtnAddKoleksi
        '
        Me.BtnAddKoleksi.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.BtnAddKoleksi.Location = New System.Drawing.Point(849, 468)
        Me.BtnAddKoleksi.Name = "BtnAddKoleksi"
        Me.BtnAddKoleksi.Size = New System.Drawing.Size(250, 39)
        Me.BtnAddKoleksi.TabIndex = 33
        Me.BtnAddKoleksi.Text = "Tambah Koleksi"
        Me.BtnAddKoleksi.UseVisualStyleBackColor = True
        '
        'CBSains
        '
        Me.CBSains.AutoSize = True
        Me.CBSains.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.CBSains.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.CBSains.Location = New System.Drawing.Point(25, 45)
        Me.CBSains.Name = "CBSains"
        Me.CBSains.Size = New System.Drawing.Size(74, 29)
        Me.CBSains.TabIndex = 0
        Me.CBSains.Text = "Sains"
        Me.CBSains.UseVisualStyleBackColor = True
        '
        'CBSosial
        '
        Me.CBSosial.AutoSize = True
        Me.CBSosial.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.CBSosial.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.CBSosial.Location = New System.Drawing.Point(25, 75)
        Me.CBSosial.Name = "CBSosial"
        Me.CBSosial.Size = New System.Drawing.Size(78, 29)
        Me.CBSosial.TabIndex = 1
        Me.CBSosial.Text = "Sosial"
        Me.CBSosial.UseVisualStyleBackColor = True
        '
        'CBTeknologi
        '
        Me.CBTeknologi.AutoSize = True
        Me.CBTeknologi.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.CBTeknologi.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.CBTeknologi.Location = New System.Drawing.Point(25, 106)
        Me.CBTeknologi.Name = "CBTeknologi"
        Me.CBTeknologi.Size = New System.Drawing.Size(104, 29)
        Me.CBTeknologi.TabIndex = 2
        Me.CBTeknologi.Text = "Teknologi"
        Me.CBTeknologi.UseVisualStyleBackColor = True
        '
        'CBBudaya
        '
        Me.CBBudaya.AutoSize = True
        Me.CBBudaya.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.CBBudaya.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.CBBudaya.Location = New System.Drawing.Point(25, 136)
        Me.CBBudaya.Name = "CBBudaya"
        Me.CBBudaya.Size = New System.Drawing.Size(89, 29)
        Me.CBBudaya.TabIndex = 3
        Me.CBBudaya.Text = "Budaya"
        Me.CBBudaya.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.GroupBox2.Controls.Add(Me.CBBudaya)
        Me.GroupBox2.Controls.Add(Me.CBTeknologi)
        Me.GroupBox2.Controls.Add(Me.CBSosial)
        Me.GroupBox2.Controls.Add(Me.CBSains)
        Me.GroupBox2.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.GroupBox2.Location = New System.Drawing.Point(849, 242)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(250, 180)
        Me.GroupBox2.TabIndex = 32
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Kategori"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'TambahKoleksi
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1173, 639)
        Me.Controls.Add(Me.BtnAddKoleksi)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.TxtBoxStock)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.DatePickTglMasuk)
        Me.Controls.Add(Me.TxtBoxLocRak)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.TxtBoxTahun)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.TxtBoxPenerbit)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.RTBdesc)
        Me.Controls.Add(Me.CBJenisKoleksi)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.TxtBoxNama)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.BtnAddImage)
        Me.Controls.Add(Me.PcbKoleksi)
        Me.Name = "TambahKoleksi"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Tambah Koleksi"
        CType(Me.PcbKoleksi, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PcbKoleksi As PictureBox
    Friend WithEvents BtnAddImage As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents TxtBoxNama As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents CBJenisKoleksi As ComboBox
    Friend WithEvents RTBdesc As RichTextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents TxtBoxPenerbit As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents TxtBoxTahun As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents TxtBoxLocRak As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents DatePickTglMasuk As DateTimePicker
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents TxtBoxStock As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents RBEnglish As RadioButton
    Friend WithEvents RBIndonesian As RadioButton
    Friend WithEvents Label20 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents BtnAddKoleksi As Button
    Friend WithEvents CBSains As CheckBox
    Friend WithEvents CBSosial As CheckBox
    Friend WithEvents CBTeknologi As CheckBox
    Friend WithEvents CBBudaya As CheckBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
End Class
