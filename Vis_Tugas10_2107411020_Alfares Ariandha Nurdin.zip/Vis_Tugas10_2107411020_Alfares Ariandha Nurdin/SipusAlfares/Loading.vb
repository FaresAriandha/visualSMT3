﻿Imports System.Threading
Public Class Loading
    Private Sub Loading_Activated(sender As Object, e As EventArgs) Handles Me.Activated
        'System.Threading.Thread.Sleep(5000)
        'Dashboard.Show()
    End Sub
End Class