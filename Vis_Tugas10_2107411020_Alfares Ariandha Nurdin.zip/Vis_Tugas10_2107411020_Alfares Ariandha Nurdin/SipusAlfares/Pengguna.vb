﻿Imports System.Security.Cryptography
Imports MySql.Data.MySqlClient

Public Class Pengguna
    Private username
    Private password
    Private TripleDes As New TripleDESCryptoServiceProvider
    Public koleksiUser As New ArrayList()

    Public Shared dbConn As New MySqlConnection
    Public Shared sqlCommand As New MySqlCommand
    Public Shared sqlRead As MySqlDataReader
    Private sqlQuery As String

    Private server As String = "localhost"
    Private username_db As String = "root"
    Private password_db As String = ""
    Private database As String = "perpustakaan"
    Public Sub New()
        dbConn.ConnectionString = "server = " + server + ";" + "user id = " _
                                  + username_db + ";" + "password = " + password_db + ";" _
                                  + "database = " + database
    End Sub

    Public Property GSusername() As String
        Get
            Return username

        End Get
        Set(ByVal value As String)
            username = value
        End Set
    End Property

    Public Property GSpassword() As String
        Get
            Return password
        End Get
        Set(ByVal value As String)
            password = value
        End Set
    End Property

    Public Function EncryptData(ByVal plainText As String) As String
        'Convert the plaintext string to a byte array
        Dim plainTextBytes() As Byte =
            System.Text.Encoding.Unicode.GetBytes(plainText)

        'Create the stream
        Dim ms As New System.IO.MemoryStream
        'Create the encoder to write to the stream
        Dim encStream As New CryptoStream(ms,
                TripleDes.CreateEncryptor(),
                System.Security.Cryptography.CryptoStreamMode.Write)

        'Use the crypto stream to write the byte array to the stream
        encStream.Write(plainTextBytes, 0, plainTextBytes.Length)
        encStream.FlushFinalBlock()

        'Convert the encrypted stream to a printable string.
        Return Convert.ToBase64String(ms.ToArray)
    End Function

    Public Function CheckAuth(ByVal plainUsername As String, ByVal plainPassword As String) As String
        'Static Password
        'Dim realPassword As String = EncryptData("1234")
        'Dim realUsername As String = "fares"

        'MsgBox(GSusername())
        For Each akun In koleksiUser
            'MsgBox(akun(0))
            If String.Compare(plainUsername, akun(0)) = 0 And String.Compare(EncryptData(plainPassword), EncryptData(akun(1))) = 0 Then
                Return "Login Berhasil"
            ElseIf String.Compare(plainUsername, akun(0)) = 0 And String.Compare(EncryptData(plainPassword), EncryptData(akun(1))) <> 0 Then
                Return "Wrong password"
            End If
            'MsgBox(EncryptData(plainPassword) & EncryptData(akun(1)))
        Next


        Return "Username not found"
        'MsgBox(String.Join(", ", koleksiUser.ToArray))
    End Function

    Public Function setUserPassKoleksi(userName As String, pass As String, fullName As String)
        'For Each kel In koleksiUser
        '    MsgBox("info")
        '    If userName = kel(0) Then
        '        Return False
        '    End If
        'Next
        'pass = EncryptData(pass)
        koleksiUser.Add({userName, pass, fullName})
        'counter += 1
        'MsgBox(koleksiUser(counter)(0))

        'For kel = 0 To counter
        '    MsgBox(kel)
        '    MsgBox(koleksiUser(kel)(0))
        'Next
        'MsgBox(counter)
        'Return True
    End Function


    Public Function EncryptDataMD5(ByVal password As String)
        Dim x As New System.Security.Cryptography.MD5CryptoServiceProvider()
        Dim bs As Byte() = System.Text.Encoding.UTF8.GetBytes(password)
        bs = x.ComputeHash(bs)

        Dim s As New System.Text.StringBuilder()
        For Each b As Byte In bs
            s.Append(b.ToString("x2").ToLower())
        Next

        Return s.ToString()
    End Function

    Public Function checkIfUsernameExist(username_regist As String)
        Dim result As Boolean

        dbConn.Open()

        sqlCommand.Connection = dbConn
        sqlCommand.CommandText = "SELECT username
                                  FROM USERS
                                  WHERE username='" & username_regist & "'"
        sqlRead = sqlCommand.ExecuteReader



        If sqlRead.HasRows Then
            result = True
        Else
            result = False
        End If

        sqlRead.Close()
        dbConn.Close()

        Return result
    End Function

    Public Function AddUsersDatabase(username_regist As String, password_regist As String)


        Try

            If checkIfUsernameExist(username_regist) Then
                MsgBox("Username Is Exist, Try to other Username", MsgBoxStyle.Exclamation, "Warning")
            Else
                Dim today = Date.Now()

                dbConn.Open()

                sqlCommand.Connection = dbConn

                sqlQuery = "INSERT INTO USERS 
                        VALUES('','" &
                            username_regist & "','" &
                            EncryptDataMD5(password_regist) & "','" &
                            today.ToString("yyyy/MM/dd") & "')"
                Debug.WriteLine(sqlQuery)

                sqlCommand = New MySqlCommand(sqlQuery, dbConn)
                sqlRead = sqlCommand.ExecuteReader

                MsgBox("Berhasil Tambah Data", MsgBoxStyle.Information, "Sukses")
                sqlRead.Close()
                dbConn.Close()
            End If
        Catch ex As Exception
            Return ex.Message
        Finally
            dbConn.Dispose()
        End Try
    End Function

    Public Function CheckAuthDatabase(username_login As String, password_login As String) As List(Of String)



        Try
            Dim result As New List(Of String)

            dbConn.Open()
            sqlCommand.Connection = dbConn
            Dim queryAuth = "SELECT id_user, username FROM users WHERE username = '" & username_login & "' AND password = '" & EncryptDataMD5(password_login) & "'"


            sqlCommand.CommandText = queryAuth
            sqlRead = sqlCommand.ExecuteReader

            If sqlRead.HasRows Then
                'MessageBox.Show(sqlRead.HasRows)
                While sqlRead.Read()
                    'MessageBox.Show(sqlRead.GetString(0).ToString())
                    result.Add(sqlRead.GetString(0).ToString())
                    result.Add(sqlRead.GetString(1).ToString())
                End While
            Else
                MessageBox.Show("kosong")
            End If

            sqlRead.Close()
            dbConn.Close()

            Return result
        Catch ex As Exception
            Debug.WriteLine(ex.Message)
        Finally
            dbConn.Dispose()
        End Try
    End Function
End Class
