﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Pertemuan_6
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TxtVariableWithIF = New System.Windows.Forms.TextBox()
        Me.ListBoxExampleVariable = New System.Windows.Forms.ListBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ListBoxTipeVariableWithSwitch = New System.Windows.Forms.ListBox()
        Me.TxtVariableWithSwitch = New System.Windows.Forms.TextBox()
        Me.TxtBoxA = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.BtnPow = New System.Windows.Forms.Button()
        Me.BtnAdd = New System.Windows.Forms.Button()
        Me.BtnSubstract = New System.Windows.Forms.Button()
        Me.BtnMultiply = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TxtBoxB = New System.Windows.Forms.TextBox()
        Me.BtnDivideInt = New System.Windows.Forms.Button()
        Me.BtnMod = New System.Windows.Forms.Button()
        Me.BtnConcat = New System.Windows.Forms.Button()
        Me.BtnDivideFloat = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TxtBoxHasil = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TxtConvertedString = New System.Windows.Forms.TextBox()
        Me.BtnToString = New System.Windows.Forms.Button()
        Me.BtnToInteger = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TxtConvertedInteger = New System.Windows.Forms.TextBox()
        Me.BtnToIntegerCInt = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TxtAge = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.LblWithSwitch = New System.Windows.Forms.Label()
        Me.LblWithIf = New System.Windows.Forms.Label()
        Me.ListBoxLoop = New System.Windows.Forms.ListBox()
        Me.BtnBeginToEnd = New System.Windows.Forms.Button()
        Me.BtnBeginToEndStep = New System.Windows.Forms.Button()
        Me.BtnDoWhileLoop = New System.Windows.Forms.Button()
        Me.BtnDoLoopWhile = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'TxtVariableWithIF
        '
        Me.TxtVariableWithIF.Location = New System.Drawing.Point(160, 78)
        Me.TxtVariableWithIF.Name = "TxtVariableWithIF"
        Me.TxtVariableWithIF.Size = New System.Drawing.Size(152, 31)
        Me.TxtVariableWithIF.TabIndex = 0
        '
        'ListBoxExampleVariable
        '
        Me.ListBoxExampleVariable.FormattingEnabled = True
        Me.ListBoxExampleVariable.ItemHeight = 25
        Me.ListBoxExampleVariable.Items.AddRange(New Object() {"Short", "UShort", "Integer", "UInteger", "Long", "ULong", "Single", "Double", "Decimal", "Byte", "SByte", "Char", "String", "Boolean", "Date"})
        Me.ListBoxExampleVariable.Location = New System.Drawing.Point(23, 78)
        Me.ListBoxExampleVariable.Name = "ListBoxExampleVariable"
        Me.ListBoxExampleVariable.Size = New System.Drawing.Size(121, 129)
        Me.ListBoxExampleVariable.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(23, 27)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(93, 25)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Dengan IF"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(385, 27)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(130, 25)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Dengan Switch"
        '
        'ListBoxTipeVariableWithSwitch
        '
        Me.ListBoxTipeVariableWithSwitch.FormattingEnabled = True
        Me.ListBoxTipeVariableWithSwitch.ItemHeight = 25
        Me.ListBoxTipeVariableWithSwitch.Items.AddRange(New Object() {"Short", "UShort", "Integer", "UInteger", "Long", "ULong", "Single", "Double", "Decimal", "Byte", "SByte", "Char", "String", "Boolean", "Date"})
        Me.ListBoxTipeVariableWithSwitch.Location = New System.Drawing.Point(385, 78)
        Me.ListBoxTipeVariableWithSwitch.Name = "ListBoxTipeVariableWithSwitch"
        Me.ListBoxTipeVariableWithSwitch.Size = New System.Drawing.Size(121, 129)
        Me.ListBoxTipeVariableWithSwitch.TabIndex = 4
        '
        'TxtVariableWithSwitch
        '
        Me.TxtVariableWithSwitch.Location = New System.Drawing.Point(522, 78)
        Me.TxtVariableWithSwitch.Name = "TxtVariableWithSwitch"
        Me.TxtVariableWithSwitch.Size = New System.Drawing.Size(152, 31)
        Me.TxtVariableWithSwitch.TabIndex = 3
        '
        'TxtBoxA
        '
        Me.TxtBoxA.Location = New System.Drawing.Point(30, 306)
        Me.TxtBoxA.Name = "TxtBoxA"
        Me.TxtBoxA.Size = New System.Drawing.Size(152, 31)
        Me.TxtBoxA.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(30, 269)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(24, 25)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "A"
        '
        'BtnPow
        '
        Me.BtnPow.Location = New System.Drawing.Point(396, 298)
        Me.BtnPow.Name = "BtnPow"
        Me.BtnPow.Size = New System.Drawing.Size(50, 35)
        Me.BtnPow.TabIndex = 8
        Me.BtnPow.Text = "^"
        Me.BtnPow.UseVisualStyleBackColor = True
        '
        'BtnAdd
        '
        Me.BtnAdd.Location = New System.Drawing.Point(452, 341)
        Me.BtnAdd.Name = "BtnAdd"
        Me.BtnAdd.Size = New System.Drawing.Size(50, 35)
        Me.BtnAdd.TabIndex = 9
        Me.BtnAdd.Text = "+"
        Me.BtnAdd.UseVisualStyleBackColor = True
        '
        'BtnSubstract
        '
        Me.BtnSubstract.Location = New System.Drawing.Point(396, 339)
        Me.BtnSubstract.Name = "BtnSubstract"
        Me.BtnSubstract.Size = New System.Drawing.Size(50, 35)
        Me.BtnSubstract.TabIndex = 10
        Me.BtnSubstract.Text = "-"
        Me.BtnSubstract.UseVisualStyleBackColor = True
        '
        'BtnMultiply
        '
        Me.BtnMultiply.Location = New System.Drawing.Point(452, 300)
        Me.BtnMultiply.Name = "BtnMultiply"
        Me.BtnMultiply.Size = New System.Drawing.Size(50, 35)
        Me.BtnMultiply.TabIndex = 11
        Me.BtnMultiply.Text = "*"
        Me.BtnMultiply.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(208, 269)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(22, 25)
        Me.Label4.TabIndex = 13
        Me.Label4.Text = "B"
        '
        'TxtBoxB
        '
        Me.TxtBoxB.Location = New System.Drawing.Point(208, 306)
        Me.TxtBoxB.Name = "TxtBoxB"
        Me.TxtBoxB.Size = New System.Drawing.Size(152, 31)
        Me.TxtBoxB.TabIndex = 12
        '
        'BtnDivideInt
        '
        Me.BtnDivideInt.Location = New System.Drawing.Point(597, 304)
        Me.BtnDivideInt.Name = "BtnDivideInt"
        Me.BtnDivideInt.Size = New System.Drawing.Size(84, 35)
        Me.BtnDivideInt.TabIndex = 17
        Me.BtnDivideInt.Text = "\"
        Me.BtnDivideInt.UseVisualStyleBackColor = True
        '
        'BtnMod
        '
        Me.BtnMod.Location = New System.Drawing.Point(524, 343)
        Me.BtnMod.Name = "BtnMod"
        Me.BtnMod.Size = New System.Drawing.Size(69, 35)
        Me.BtnMod.TabIndex = 16
        Me.BtnMod.Text = "Mod"
        Me.BtnMod.UseVisualStyleBackColor = True
        '
        'BtnConcat
        '
        Me.BtnConcat.Location = New System.Drawing.Point(599, 345)
        Me.BtnConcat.Name = "BtnConcat"
        Me.BtnConcat.Size = New System.Drawing.Size(82, 35)
        Me.BtnConcat.TabIndex = 15
        Me.BtnConcat.Text = "Concat"
        Me.BtnConcat.UseVisualStyleBackColor = True
        '
        'BtnDivideFloat
        '
        Me.BtnDivideFloat.Location = New System.Drawing.Point(524, 302)
        Me.BtnDivideFloat.Name = "BtnDivideFloat"
        Me.BtnDivideFloat.Size = New System.Drawing.Size(69, 35)
        Me.BtnDivideFloat.TabIndex = 14
        Me.BtnDivideFloat.Text = "/"
        Me.BtnDivideFloat.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(30, 357)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(50, 25)
        Me.Label5.TabIndex = 19
        Me.Label5.Text = "Hasil"
        '
        'TxtBoxHasil
        '
        Me.TxtBoxHasil.Location = New System.Drawing.Point(30, 394)
        Me.TxtBoxHasil.Name = "TxtBoxHasil"
        Me.TxtBoxHasil.Size = New System.Drawing.Size(152, 31)
        Me.TxtBoxHasil.TabIndex = 18
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.SystemColors.Info
        Me.Label6.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label6.Location = New System.Drawing.Point(30, 230)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(222, 32)
        Me.Label6.TabIndex = 20
        Me.Label6.Text = "Kalkutor Sederhana"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(782, 41)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(58, 25)
        Me.Label7.TabIndex = 22
        Me.Label7.Text = "String"
        '
        'TxtConvertedString
        '
        Me.TxtConvertedString.Location = New System.Drawing.Point(782, 78)
        Me.TxtConvertedString.Name = "TxtConvertedString"
        Me.TxtConvertedString.Size = New System.Drawing.Size(152, 31)
        Me.TxtConvertedString.TabIndex = 21
        '
        'BtnToString
        '
        Me.BtnToString.Location = New System.Drawing.Point(940, 78)
        Me.BtnToString.Name = "BtnToString"
        Me.BtnToString.Size = New System.Drawing.Size(91, 35)
        Me.BtnToString.TabIndex = 23
        Me.BtnToString.Text = "ToString"
        Me.BtnToString.UseVisualStyleBackColor = True
        '
        'BtnToInteger
        '
        Me.BtnToInteger.Location = New System.Drawing.Point(940, 166)
        Me.BtnToInteger.Name = "BtnToInteger"
        Me.BtnToInteger.Size = New System.Drawing.Size(91, 35)
        Me.BtnToInteger.TabIndex = 26
        Me.BtnToInteger.Text = "ParseInt"
        Me.BtnToInteger.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(782, 129)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(68, 25)
        Me.Label8.TabIndex = 25
        Me.Label8.Text = "Integer"
        '
        'TxtConvertedInteger
        '
        Me.TxtConvertedInteger.Location = New System.Drawing.Point(782, 166)
        Me.TxtConvertedInteger.Name = "TxtConvertedInteger"
        Me.TxtConvertedInteger.Size = New System.Drawing.Size(152, 31)
        Me.TxtConvertedInteger.TabIndex = 24
        '
        'BtnToIntegerCInt
        '
        Me.BtnToIntegerCInt.Location = New System.Drawing.Point(1053, 166)
        Me.BtnToIntegerCInt.Name = "BtnToIntegerCInt"
        Me.BtnToIntegerCInt.Size = New System.Drawing.Size(91, 35)
        Me.BtnToIntegerCInt.TabIndex = 27
        Me.BtnToIntegerCInt.Text = "CInt"
        Me.BtnToIntegerCInt.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(901, 240)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(103, 25)
        Me.Label9.TabIndex = 29
        Me.Label9.Text = "Umur Anda"
        '
        'TxtAge
        '
        Me.TxtAge.Location = New System.Drawing.Point(879, 281)
        Me.TxtAge.Name = "TxtAge"
        Me.TxtAge.Size = New System.Drawing.Size(152, 31)
        Me.TxtAge.TabIndex = 28
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label10.Location = New System.Drawing.Point(782, 339)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(98, 25)
        Me.Label10.TabIndex = 30
        Me.Label10.Text = "Dengan IF"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label11.Location = New System.Drawing.Point(1014, 339)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(139, 25)
        Me.Label11.TabIndex = 31
        Me.Label11.Text = "Dengan Switch"
        '
        'LblWithSwitch
        '
        Me.LblWithSwitch.AutoSize = True
        Me.LblWithSwitch.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.LblWithSwitch.ForeColor = System.Drawing.Color.Red
        Me.LblWithSwitch.Location = New System.Drawing.Point(1014, 381)
        Me.LblWithSwitch.Name = "LblWithSwitch"
        Me.LblWithSwitch.Size = New System.Drawing.Size(139, 25)
        Me.LblWithSwitch.TabIndex = 33
        Me.LblWithSwitch.Text = "Dengan Switch"
        '
        'LblWithIf
        '
        Me.LblWithIf.AutoSize = True
        Me.LblWithIf.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.LblWithIf.ForeColor = System.Drawing.Color.Red
        Me.LblWithIf.Location = New System.Drawing.Point(782, 381)
        Me.LblWithIf.Name = "LblWithIf"
        Me.LblWithIf.Size = New System.Drawing.Size(98, 25)
        Me.LblWithIf.TabIndex = 32
        Me.LblWithIf.Text = "Dengan IF"
        '
        'ListBoxLoop
        '
        Me.ListBoxLoop.FormattingEnabled = True
        Me.ListBoxLoop.ItemHeight = 25
        Me.ListBoxLoop.Location = New System.Drawing.Point(29, 452)
        Me.ListBoxLoop.Name = "ListBoxLoop"
        Me.ListBoxLoop.Size = New System.Drawing.Size(158, 104)
        Me.ListBoxLoop.TabIndex = 34
        '
        'BtnBeginToEnd
        '
        Me.BtnBeginToEnd.Location = New System.Drawing.Point(220, 452)
        Me.BtnBeginToEnd.Name = "BtnBeginToEnd"
        Me.BtnBeginToEnd.Size = New System.Drawing.Size(208, 35)
        Me.BtnBeginToEnd.TabIndex = 35
        Me.BtnBeginToEnd.Text = "For Begin To End"
        Me.BtnBeginToEnd.UseVisualStyleBackColor = True
        '
        'BtnBeginToEndStep
        '
        Me.BtnBeginToEndStep.Location = New System.Drawing.Point(220, 493)
        Me.BtnBeginToEndStep.Name = "BtnBeginToEndStep"
        Me.BtnBeginToEndStep.Size = New System.Drawing.Size(208, 35)
        Me.BtnBeginToEndStep.TabIndex = 36
        Me.BtnBeginToEndStep.Text = "For Begin To End Step"
        Me.BtnBeginToEndStep.UseVisualStyleBackColor = True
        '
        'BtnDoWhileLoop
        '
        Me.BtnDoWhileLoop.Location = New System.Drawing.Point(434, 452)
        Me.BtnDoWhileLoop.Name = "BtnDoWhileLoop"
        Me.BtnDoWhileLoop.Size = New System.Drawing.Size(159, 35)
        Me.BtnDoWhileLoop.TabIndex = 37
        Me.BtnDoWhileLoop.Text = "Do While Loop"
        Me.BtnDoWhileLoop.UseVisualStyleBackColor = True
        '
        'BtnDoLoopWhile
        '
        Me.BtnDoLoopWhile.Location = New System.Drawing.Point(434, 493)
        Me.BtnDoLoopWhile.Name = "BtnDoLoopWhile"
        Me.BtnDoLoopWhile.Size = New System.Drawing.Size(159, 35)
        Me.BtnDoLoopWhile.TabIndex = 38
        Me.BtnDoLoopWhile.Text = "Do Loop While"
        Me.BtnDoLoopWhile.UseVisualStyleBackColor = True
        '
        'Pertemuan_6
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1346, 585)
        Me.Controls.Add(Me.BtnDoLoopWhile)
        Me.Controls.Add(Me.BtnDoWhileLoop)
        Me.Controls.Add(Me.BtnBeginToEndStep)
        Me.Controls.Add(Me.BtnBeginToEnd)
        Me.Controls.Add(Me.ListBoxLoop)
        Me.Controls.Add(Me.LblWithSwitch)
        Me.Controls.Add(Me.LblWithIf)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.TxtAge)
        Me.Controls.Add(Me.BtnToIntegerCInt)
        Me.Controls.Add(Me.BtnToInteger)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.TxtConvertedInteger)
        Me.Controls.Add(Me.BtnToString)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.TxtConvertedString)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.TxtBoxHasil)
        Me.Controls.Add(Me.BtnDivideInt)
        Me.Controls.Add(Me.BtnMod)
        Me.Controls.Add(Me.BtnConcat)
        Me.Controls.Add(Me.BtnDivideFloat)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.TxtBoxB)
        Me.Controls.Add(Me.BtnMultiply)
        Me.Controls.Add(Me.BtnSubstract)
        Me.Controls.Add(Me.BtnAdd)
        Me.Controls.Add(Me.BtnPow)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TxtBoxA)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.ListBoxTipeVariableWithSwitch)
        Me.Controls.Add(Me.TxtVariableWithSwitch)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ListBoxExampleVariable)
        Me.Controls.Add(Me.TxtVariableWithIF)
        Me.Name = "Pertemuan_6"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Pertemuan_6"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TxtVariableWithIF As TextBox
    Friend WithEvents ListBoxExampleVariable As ListBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents ListBoxTipeVariableWithSwitch As ListBox
    Friend WithEvents TxtVariableWithSwitch As TextBox
    Friend WithEvents TxtBoxA As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents BtnPow As Button
    Friend WithEvents BtnAdd As Button
    Friend WithEvents BtnSubstract As Button
    Friend WithEvents BtnMultiply As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents TxtBoxB As TextBox
    Friend WithEvents BtnDivideInt As Button
    Friend WithEvents BtnMod As Button
    Friend WithEvents BtnConcat As Button
    Friend WithEvents BtnDivideFloat As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents TxtBoxHasil As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents TxtConvertedString As TextBox
    Friend WithEvents BtnToString As Button
    Friend WithEvents BtnToInteger As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents TxtConvertedInteger As TextBox
    Friend WithEvents BtnToIntegerCInt As Button
    Friend WithEvents Label9 As Label
    Friend WithEvents TxtAge As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents LblWithSwitch As Label
    Friend WithEvents LblWithIf As Label
    Friend WithEvents ListBoxLoop As ListBox
    Friend WithEvents BtnBeginToEnd As Button
    Friend WithEvents BtnBeginToEndStep As Button
    Friend WithEvents BtnDoWhileLoop As Button
    Friend WithEvents BtnDoLoopWhile As Button
End Class
