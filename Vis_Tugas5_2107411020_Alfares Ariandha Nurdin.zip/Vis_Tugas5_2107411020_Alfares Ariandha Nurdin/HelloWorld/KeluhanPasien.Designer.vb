﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class KeluhanPasien
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.BtnShowKeluhan = New System.Windows.Forms.Button()
        Me.ChkDemam = New System.Windows.Forms.CheckBox()
        Me.ChkMual = New System.Windows.Forms.CheckBox()
        Me.ChkPusing = New System.Windows.Forms.CheckBox()
        Me.BtnTransfer = New System.Windows.Forms.Button()
        Me.ListBoxKeluhan = New System.Windows.Forms.ListBox()
        Me.BtnListCheck = New System.Windows.Forms.Button()
        Me.CheckedListBoxKeluhan = New System.Windows.Forms.CheckedListBox()
        Me.TxtBoxLsb2 = New System.Windows.Forms.TextBox()
        Me.BtnToLsb2 = New System.Windows.Forms.Button()
        Me.LsbKeluhan2 = New System.Windows.Forms.ListBox()
        Me.BtnSelectedItem = New System.Windows.Forms.Button()
        Me.BtnShowCHKLSBX = New System.Windows.Forms.Button()
        Me.ComboBoxLayanan = New System.Windows.Forms.ComboBox()
        Me.BtnComboBox = New System.Windows.Forms.Button()
        Me.BtnToRegis = New System.Windows.Forms.Button()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox2.Controls.Add(Me.BtnShowKeluhan)
        Me.GroupBox2.Controls.Add(Me.ChkDemam)
        Me.GroupBox2.Controls.Add(Me.ChkMual)
        Me.GroupBox2.Controls.Add(Me.ChkPusing)
        Me.GroupBox2.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.GroupBox2.Location = New System.Drawing.Point(423, 39)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(190, 230)
        Me.GroupBox2.TabIndex = 19
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Keluhan"
        '
        'BtnShowKeluhan
        '
        Me.BtnShowKeluhan.BackColor = System.Drawing.SystemColors.ControlDark
        Me.BtnShowKeluhan.Font = New System.Drawing.Font("Franklin Gothic Demi Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.BtnShowKeluhan.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.BtnShowKeluhan.Location = New System.Drawing.Point(31, 174)
        Me.BtnShowKeluhan.Name = "BtnShowKeluhan"
        Me.BtnShowKeluhan.Size = New System.Drawing.Size(129, 42)
        Me.BtnShowKeluhan.TabIndex = 22
        Me.BtnShowKeluhan.Text = "Output"
        Me.BtnShowKeluhan.UseVisualStyleBackColor = False
        '
        'ChkDemam
        '
        Me.ChkDemam.AutoSize = True
        Me.ChkDemam.Location = New System.Drawing.Point(31, 130)
        Me.ChkDemam.Name = "ChkDemam"
        Me.ChkDemam.Size = New System.Drawing.Size(108, 34)
        Me.ChkDemam.TabIndex = 2
        Me.ChkDemam.Text = "Demam"
        Me.ChkDemam.UseVisualStyleBackColor = True
        '
        'ChkMual
        '
        Me.ChkMual.AutoSize = True
        Me.ChkMual.Location = New System.Drawing.Point(31, 90)
        Me.ChkMual.Name = "ChkMual"
        Me.ChkMual.Size = New System.Drawing.Size(83, 34)
        Me.ChkMual.TabIndex = 1
        Me.ChkMual.Text = "Mual"
        Me.ChkMual.UseVisualStyleBackColor = True
        '
        'ChkPusing
        '
        Me.ChkPusing.AutoSize = True
        Me.ChkPusing.Location = New System.Drawing.Point(31, 50)
        Me.ChkPusing.Name = "ChkPusing"
        Me.ChkPusing.Size = New System.Drawing.Size(98, 34)
        Me.ChkPusing.TabIndex = 0
        Me.ChkPusing.Text = "Pusing"
        Me.ChkPusing.UseVisualStyleBackColor = True
        '
        'BtnTransfer
        '
        Me.BtnTransfer.BackColor = System.Drawing.SystemColors.ControlDark
        Me.BtnTransfer.Font = New System.Drawing.Font("Franklin Gothic Demi Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.BtnTransfer.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.BtnTransfer.Location = New System.Drawing.Point(676, 186)
        Me.BtnTransfer.Name = "BtnTransfer"
        Me.BtnTransfer.Size = New System.Drawing.Size(287, 42)
        Me.BtnTransfer.TabIndex = 23
        Me.BtnTransfer.Text = "Transfer List Box"
        Me.BtnTransfer.UseVisualStyleBackColor = False
        '
        'ListBoxKeluhan
        '
        Me.ListBoxKeluhan.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.ListBoxKeluhan.FormattingEnabled = True
        Me.ListBoxKeluhan.ItemHeight = 30
        Me.ListBoxKeluhan.Items.AddRange(New Object() {""})
        Me.ListBoxKeluhan.Location = New System.Drawing.Point(676, 39)
        Me.ListBoxKeluhan.Name = "ListBoxKeluhan"
        Me.ListBoxKeluhan.Size = New System.Drawing.Size(287, 124)
        Me.ListBoxKeluhan.TabIndex = 24
        '
        'BtnListCheck
        '
        Me.BtnListCheck.BackColor = System.Drawing.SystemColors.ControlDark
        Me.BtnListCheck.Font = New System.Drawing.Font("Franklin Gothic Demi Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.BtnListCheck.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.BtnListCheck.Location = New System.Drawing.Point(74, 186)
        Me.BtnListCheck.Name = "BtnListCheck"
        Me.BtnListCheck.Size = New System.Drawing.Size(315, 42)
        Me.BtnListCheck.TabIndex = 25
        Me.BtnListCheck.Text = "Transfer List Check"
        Me.BtnListCheck.UseVisualStyleBackColor = False
        '
        'CheckedListBoxKeluhan
        '
        Me.CheckedListBoxKeluhan.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.CheckedListBoxKeluhan.FormattingEnabled = True
        Me.CheckedListBoxKeluhan.Items.AddRange(New Object() {"Pusing", "Mual", "Demam"})
        Me.CheckedListBoxKeluhan.Location = New System.Drawing.Point(74, 39)
        Me.CheckedListBoxKeluhan.Name = "CheckedListBoxKeluhan"
        Me.CheckedListBoxKeluhan.Size = New System.Drawing.Size(315, 132)
        Me.CheckedListBoxKeluhan.TabIndex = 26
        '
        'TxtBoxLsb2
        '
        Me.TxtBoxLsb2.Location = New System.Drawing.Point(72, 339)
        Me.TxtBoxLsb2.Name = "TxtBoxLsb2"
        Me.TxtBoxLsb2.Size = New System.Drawing.Size(233, 31)
        Me.TxtBoxLsb2.TabIndex = 27
        '
        'BtnToLsb2
        '
        Me.BtnToLsb2.BackColor = System.Drawing.SystemColors.ControlDark
        Me.BtnToLsb2.Font = New System.Drawing.Font("Franklin Gothic Demi Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.BtnToLsb2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.BtnToLsb2.Location = New System.Drawing.Point(72, 376)
        Me.BtnToLsb2.Name = "BtnToLsb2"
        Me.BtnToLsb2.Size = New System.Drawing.Size(233, 42)
        Me.BtnToLsb2.TabIndex = 29
        Me.BtnToLsb2.Text = "Add Item"
        Me.BtnToLsb2.UseVisualStyleBackColor = False
        '
        'LsbKeluhan2
        '
        Me.LsbKeluhan2.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.LsbKeluhan2.FormattingEnabled = True
        Me.LsbKeluhan2.ItemHeight = 30
        Me.LsbKeluhan2.Location = New System.Drawing.Point(74, 436)
        Me.LsbKeluhan2.Name = "LsbKeluhan2"
        Me.LsbKeluhan2.Size = New System.Drawing.Size(231, 124)
        Me.LsbKeluhan2.TabIndex = 30
        '
        'BtnSelectedItem
        '
        Me.BtnSelectedItem.BackColor = System.Drawing.SystemColors.ControlDark
        Me.BtnSelectedItem.Font = New System.Drawing.Font("Franklin Gothic Demi Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.BtnSelectedItem.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.BtnSelectedItem.Location = New System.Drawing.Point(74, 566)
        Me.BtnSelectedItem.Name = "BtnSelectedItem"
        Me.BtnSelectedItem.Size = New System.Drawing.Size(231, 42)
        Me.BtnSelectedItem.TabIndex = 31
        Me.BtnSelectedItem.Text = "Show Selected Item"
        Me.BtnSelectedItem.UseVisualStyleBackColor = False
        '
        'BtnShowCHKLSBX
        '
        Me.BtnShowCHKLSBX.BackColor = System.Drawing.SystemColors.ControlDark
        Me.BtnShowCHKLSBX.Font = New System.Drawing.Font("Franklin Gothic Demi Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.BtnShowCHKLSBX.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.BtnShowCHKLSBX.Location = New System.Drawing.Point(74, 234)
        Me.BtnShowCHKLSBX.Name = "BtnShowCHKLSBX"
        Me.BtnShowCHKLSBX.Size = New System.Drawing.Size(315, 42)
        Me.BtnShowCHKLSBX.TabIndex = 32
        Me.BtnShowCHKLSBX.Text = "Show Selected Item"
        Me.BtnShowCHKLSBX.UseVisualStyleBackColor = False
        '
        'ComboBoxLayanan
        '
        Me.ComboBoxLayanan.FormattingEnabled = True
        Me.ComboBoxLayanan.Location = New System.Drawing.Point(423, 339)
        Me.ComboBoxLayanan.Name = "ComboBoxLayanan"
        Me.ComboBoxLayanan.Size = New System.Drawing.Size(224, 33)
        Me.ComboBoxLayanan.TabIndex = 33
        '
        'BtnComboBox
        '
        Me.BtnComboBox.BackColor = System.Drawing.SystemColors.ControlDark
        Me.BtnComboBox.Font = New System.Drawing.Font("Franklin Gothic Demi Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.BtnComboBox.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.BtnComboBox.Location = New System.Drawing.Point(423, 383)
        Me.BtnComboBox.Name = "BtnComboBox"
        Me.BtnComboBox.Size = New System.Drawing.Size(224, 42)
        Me.BtnComboBox.TabIndex = 34
        Me.BtnComboBox.Text = "Show Selected Item"
        Me.BtnComboBox.UseVisualStyleBackColor = False
        '
        'BtnToRegis
        '
        Me.BtnToRegis.BackColor = System.Drawing.SystemColors.ControlDark
        Me.BtnToRegis.Font = New System.Drawing.Font("Franklin Gothic Demi Cond", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.BtnToRegis.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.BtnToRegis.Location = New System.Drawing.Point(690, 605)
        Me.BtnToRegis.Name = "BtnToRegis"
        Me.BtnToRegis.Size = New System.Drawing.Size(315, 42)
        Me.BtnToRegis.TabIndex = 35
        Me.BtnToRegis.Text = "Back To Form"
        Me.BtnToRegis.UseVisualStyleBackColor = False
        '
        'KeluhanPasien
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1052, 742)
        Me.Controls.Add(Me.BtnToRegis)
        Me.Controls.Add(Me.BtnComboBox)
        Me.Controls.Add(Me.ComboBoxLayanan)
        Me.Controls.Add(Me.BtnShowCHKLSBX)
        Me.Controls.Add(Me.BtnSelectedItem)
        Me.Controls.Add(Me.LsbKeluhan2)
        Me.Controls.Add(Me.BtnToLsb2)
        Me.Controls.Add(Me.TxtBoxLsb2)
        Me.Controls.Add(Me.CheckedListBoxKeluhan)
        Me.Controls.Add(Me.BtnListCheck)
        Me.Controls.Add(Me.ListBoxKeluhan)
        Me.Controls.Add(Me.BtnTransfer)
        Me.Controls.Add(Me.GroupBox2)
        Me.Name = "KeluhanPasien"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Keluhan Pasien"
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents BtnShowKeluhan As Button
    Friend WithEvents ChkDemam As CheckBox
    Friend WithEvents ChkMual As CheckBox
    Friend WithEvents ChkPusing As CheckBox
    Friend WithEvents BtnTransfer As Button
    Friend WithEvents ListBoxKeluhan As ListBox
    Friend WithEvents BtnListCheck As Button
    Friend WithEvents CheckedListBoxKeluhan As CheckedListBox
    Friend WithEvents TxtBoxLsb2 As TextBox
    Friend WithEvents BtnToLsb2 As Button
    Friend WithEvents LsbKeluhan2 As ListBox
    Friend WithEvents BtnSelectedItem As Button
    Friend WithEvents BtnShowCHKLSBX As Button
    Friend WithEvents ComboBoxLayanan As ComboBox
    Friend WithEvents BtnComboBox As Button
    Friend WithEvents BtnToRegis As Button
End Class
