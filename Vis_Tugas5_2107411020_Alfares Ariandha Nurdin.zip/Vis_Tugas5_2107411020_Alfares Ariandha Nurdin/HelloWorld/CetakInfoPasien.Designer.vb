﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class InfoPasien
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.PcbPasien = New System.Windows.Forms.PictureBox()
        Me.Nama = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.LblName = New System.Windows.Forms.Label()
        Me.LblNIK = New System.Windows.Forms.Label()
        Me.LblAddress = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.ListBoxKeluhan = New System.Windows.Forms.ListBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.LblJK = New System.Windows.Forms.Label()
        Me.LblBirth = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.LblLayanan = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.LblCtnDok = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.LblJmlHari = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.LblBiayaInap = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.BtnCtkPasienBack = New System.Windows.Forms.Button()
        CType(Me.PcbPasien, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PcbPasien
        '
        Me.PcbPasien.Location = New System.Drawing.Point(25, 32)
        Me.PcbPasien.Margin = New System.Windows.Forms.Padding(2)
        Me.PcbPasien.Name = "PcbPasien"
        Me.PcbPasien.Size = New System.Drawing.Size(149, 149)
        Me.PcbPasien.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PcbPasien.TabIndex = 0
        Me.PcbPasien.TabStop = False
        Me.PcbPasien.UseWaitCursor = True
        '
        'Nama
        '
        Me.Nama.AutoSize = True
        Me.Nama.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Nama.Location = New System.Drawing.Point(205, 35)
        Me.Nama.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Nama.Name = "Nama"
        Me.Nama.Size = New System.Drawing.Size(143, 25)
        Me.Nama.TabIndex = 1
        Me.Nama.Text = "Nama Lengkap"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label2.Location = New System.Drawing.Point(574, 143)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(74, 25)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Alamat"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label3.Location = New System.Drawing.Point(205, 89)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(42, 25)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "NIK"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label4.Location = New System.Drawing.Point(354, 35)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(17, 25)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = ":"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label5.Location = New System.Drawing.Point(354, 89)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(17, 25)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = ":"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label7.Location = New System.Drawing.Point(724, 143)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(17, 25)
        Me.Label7.TabIndex = 8
        Me.Label7.Text = ":"
        '
        'LblName
        '
        Me.LblName.AutoSize = True
        Me.LblName.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.LblName.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.LblName.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.LblName.Location = New System.Drawing.Point(374, 36)
        Me.LblName.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LblName.Name = "LblName"
        Me.LblName.Size = New System.Drawing.Size(100, 24)
        Me.LblName.TabIndex = 9
        Me.LblName.Text = "Name Place"
        '
        'LblNIK
        '
        Me.LblNIK.AutoSize = True
        Me.LblNIK.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.LblNIK.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.LblNIK.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.LblNIK.Location = New System.Drawing.Point(374, 90)
        Me.LblNIK.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LblNIK.Name = "LblNIK"
        Me.LblNIK.Size = New System.Drawing.Size(83, 24)
        Me.LblNIK.TabIndex = 10
        Me.LblNIK.Text = "NIK Place"
        '
        'LblAddress
        '
        Me.LblAddress.AutoSize = True
        Me.LblAddress.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.LblAddress.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.LblAddress.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.LblAddress.Location = New System.Drawing.Point(744, 144)
        Me.LblAddress.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LblAddress.Name = "LblAddress"
        Me.LblAddress.Size = New System.Drawing.Size(114, 24)
        Me.LblAddress.TabIndex = 12
        Me.LblAddress.Text = "Address Place"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Label8.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label8.Location = New System.Drawing.Point(199, 345)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(0, 24)
        Me.Label8.TabIndex = 15
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label9.Location = New System.Drawing.Point(112, 344)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(17, 25)
        Me.Label9.TabIndex = 14
        Me.Label9.Text = ":"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label10.Location = New System.Drawing.Point(29, 344)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(83, 25)
        Me.Label10.TabIndex = 13
        Me.Label10.Text = "Keluhan"
        '
        'ListBoxKeluhan
        '
        Me.ListBoxKeluhan.FormattingEnabled = True
        Me.ListBoxKeluhan.ItemHeight = 20
        Me.ListBoxKeluhan.Location = New System.Drawing.Point(36, 380)
        Me.ListBoxKeluhan.Margin = New System.Windows.Forms.Padding(2)
        Me.ListBoxKeluhan.Name = "ListBoxKeluhan"
        Me.ListBoxKeluhan.Size = New System.Drawing.Size(358, 144)
        Me.ListBoxKeluhan.TabIndex = 16
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label1.Location = New System.Drawing.Point(205, 192)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(130, 25)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Jenis Kelamin"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label6.Location = New System.Drawing.Point(354, 192)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(17, 25)
        Me.Label6.TabIndex = 7
        Me.Label6.Text = ":"
        '
        'LblJK
        '
        Me.LblJK.AutoSize = True
        Me.LblJK.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.LblJK.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.LblJK.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.LblJK.Location = New System.Drawing.Point(374, 193)
        Me.LblJK.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LblJK.Name = "LblJK"
        Me.LblJK.Size = New System.Drawing.Size(74, 24)
        Me.LblJK.TabIndex = 11
        Me.LblJK.Text = "JK Place"
        '
        'LblBirth
        '
        Me.LblBirth.AutoSize = True
        Me.LblBirth.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.LblBirth.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.LblBirth.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.LblBirth.Location = New System.Drawing.Point(374, 141)
        Me.LblBirth.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LblBirth.Name = "LblBirth"
        Me.LblBirth.Size = New System.Drawing.Size(70, 24)
        Me.LblBirth.TabIndex = 19
        Me.LblBirth.Text = "Birthday"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label12.Location = New System.Drawing.Point(354, 140)
        Me.Label12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(17, 25)
        Me.Label12.TabIndex = 18
        Me.Label12.Text = ":"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label13.Location = New System.Drawing.Point(205, 140)
        Me.Label13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(128, 25)
        Me.Label13.TabIndex = 17
        Me.Label13.Text = "Tanggal Lahir"
        '
        'LblLayanan
        '
        Me.LblLayanan.AutoSize = True
        Me.LblLayanan.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.LblLayanan.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.LblLayanan.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.LblLayanan.Location = New System.Drawing.Point(744, 192)
        Me.LblLayanan.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LblLayanan.Name = "LblLayanan"
        Me.LblLayanan.Size = New System.Drawing.Size(73, 24)
        Me.LblLayanan.TabIndex = 22
        Me.LblLayanan.Text = "Layanan"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label14.Location = New System.Drawing.Point(724, 191)
        Me.Label14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(17, 25)
        Me.Label14.TabIndex = 21
        Me.Label14.Text = ":"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label15.Location = New System.Drawing.Point(574, 191)
        Me.Label15.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(86, 25)
        Me.Label15.TabIndex = 20
        Me.Label15.Text = "Layanan"
        '
        'LblCtnDok
        '
        Me.LblCtnDok.AutoSize = True
        Me.LblCtnDok.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.LblCtnDok.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.LblCtnDok.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.LblCtnDok.Location = New System.Drawing.Point(744, 250)
        Me.LblCtnDok.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LblCtnDok.Name = "LblCtnDok"
        Me.LblCtnDok.Size = New System.Drawing.Size(68, 24)
        Me.LblCtnDok.TabIndex = 25
        Me.LblCtnDok.Text = "Catatan"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label16.Location = New System.Drawing.Point(724, 250)
        Me.Label16.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(17, 25)
        Me.Label16.TabIndex = 24
        Me.Label16.Text = ":"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label17.Location = New System.Drawing.Point(574, 250)
        Me.Label17.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(143, 25)
        Me.Label17.TabIndex = 23
        Me.Label17.Text = "Catatan Dokter"
        '
        'LblJmlHari
        '
        Me.LblJmlHari.AutoSize = True
        Me.LblJmlHari.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.LblJmlHari.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.LblJmlHari.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.LblJmlHari.Location = New System.Drawing.Point(770, 390)
        Me.LblJmlHari.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LblJmlHari.Name = "LblJmlHari"
        Me.LblJmlHari.Size = New System.Drawing.Size(97, 24)
        Me.LblJmlHari.TabIndex = 28
        Me.LblJmlHari.Text = "Jumlah Hari"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label18.Location = New System.Drawing.Point(750, 390)
        Me.Label18.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(17, 25)
        Me.Label18.TabIndex = 27
        Me.Label18.Text = ":"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label19.Location = New System.Drawing.Point(574, 390)
        Me.Label19.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(158, 25)
        Me.Label19.TabIndex = 26
        Me.Label19.Text = "Jumlah Hari Inap"
        '
        'LblBiayaInap
        '
        Me.LblBiayaInap.AutoSize = True
        Me.LblBiayaInap.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.LblBiayaInap.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.LblBiayaInap.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.LblBiayaInap.Location = New System.Drawing.Point(770, 434)
        Me.LblBiayaInap.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LblBiayaInap.Name = "LblBiayaInap"
        Me.LblBiayaInap.Size = New System.Drawing.Size(92, 24)
        Me.LblBiayaInap.TabIndex = 31
        Me.LblBiayaInap.Text = "Total Biaya"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label21.Location = New System.Drawing.Point(574, 434)
        Me.Label21.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(103, 25)
        Me.Label21.TabIndex = 29
        Me.Label21.Text = "Biaya Inap"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label20.Location = New System.Drawing.Point(750, 434)
        Me.Label20.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(17, 25)
        Me.Label20.TabIndex = 30
        Me.Label20.Text = ":"
        '
        'BtnCtkPasienBack
        '
        Me.BtnCtkPasienBack.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.BtnCtkPasienBack.Font = New System.Drawing.Font("Franklin Gothic Medium Cond", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.BtnCtkPasienBack.Location = New System.Drawing.Point(874, 490)
        Me.BtnCtkPasienBack.Name = "BtnCtkPasienBack"
        Me.BtnCtkPasienBack.Size = New System.Drawing.Size(153, 51)
        Me.BtnCtkPasienBack.TabIndex = 32
        Me.BtnCtkPasienBack.Text = "Back"
        Me.BtnCtkPasienBack.UseVisualStyleBackColor = False
        '
        'InfoPasien
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Info
        Me.ClientSize = New System.Drawing.Size(1066, 553)
        Me.Controls.Add(Me.BtnCtkPasienBack)
        Me.Controls.Add(Me.LblBiayaInap)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.LblJmlHari)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.LblCtnDok)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.LblLayanan)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.LblBirth)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.ListBoxKeluhan)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.LblAddress)
        Me.Controls.Add(Me.LblJK)
        Me.Controls.Add(Me.LblNIK)
        Me.Controls.Add(Me.LblName)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Nama)
        Me.Controls.Add(Me.PcbPasien)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "InfoPasien"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Cetak Info Pasien"
        CType(Me.PcbPasien, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PcbPasien As PictureBox
    Friend WithEvents Nama As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents LblName As Label
    Friend WithEvents LblNIK As Label
    Friend WithEvents LblAddress As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents ListBoxKeluhan As ListBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents LblJK As Label
    Friend WithEvents LblBirth As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents LblLayanan As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents LblCtnDok As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents LblJmlHari As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents LblBiayaInap As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents BtnCtkPasienBack As Button
End Class
