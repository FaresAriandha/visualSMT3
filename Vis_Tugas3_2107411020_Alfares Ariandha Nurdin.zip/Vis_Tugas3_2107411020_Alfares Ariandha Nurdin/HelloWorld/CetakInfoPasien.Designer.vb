﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class InfoPasien
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.PcbPasien = New System.Windows.Forms.PictureBox()
        Me.Nama = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.LblName = New System.Windows.Forms.Label()
        Me.LblNIK = New System.Windows.Forms.Label()
        Me.LblAddress = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.ListBoxKeluhan = New System.Windows.Forms.ListBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.LblJK = New System.Windows.Forms.Label()
        Me.LblBirth = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.LblLayanan = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.LblCtnDok = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        CType(Me.PcbPasien, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PcbPasien
        '
        Me.PcbPasien.Location = New System.Drawing.Point(31, 40)
        Me.PcbPasien.Name = "PcbPasien"
        Me.PcbPasien.Size = New System.Drawing.Size(186, 186)
        Me.PcbPasien.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PcbPasien.TabIndex = 0
        Me.PcbPasien.TabStop = False
        Me.PcbPasien.UseWaitCursor = True
        '
        'Nama
        '
        Me.Nama.AutoSize = True
        Me.Nama.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Nama.Location = New System.Drawing.Point(256, 44)
        Me.Nama.Name = "Nama"
        Me.Nama.Size = New System.Drawing.Size(170, 30)
        Me.Nama.TabIndex = 1
        Me.Nama.Text = "Nama Lengkap"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label2.Location = New System.Drawing.Point(718, 179)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(87, 30)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Alamat"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label3.Location = New System.Drawing.Point(256, 111)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(50, 30)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "NIK"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label4.Location = New System.Drawing.Point(443, 44)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(19, 30)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = ":"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label5.Location = New System.Drawing.Point(443, 111)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(19, 30)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = ":"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label7.Location = New System.Drawing.Point(905, 179)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(19, 30)
        Me.Label7.TabIndex = 8
        Me.Label7.Text = ":"
        '
        'LblName
        '
        Me.LblName.AutoSize = True
        Me.LblName.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.LblName.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.LblName.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.LblName.Location = New System.Drawing.Point(468, 45)
        Me.LblName.Name = "LblName"
        Me.LblName.Size = New System.Drawing.Size(119, 29)
        Me.LblName.TabIndex = 9
        Me.LblName.Text = "Name Place"
        '
        'LblNIK
        '
        Me.LblNIK.AutoSize = True
        Me.LblNIK.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.LblNIK.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.LblNIK.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.LblNIK.Location = New System.Drawing.Point(468, 112)
        Me.LblNIK.Name = "LblNIK"
        Me.LblNIK.Size = New System.Drawing.Size(98, 29)
        Me.LblNIK.TabIndex = 10
        Me.LblNIK.Text = "NIK Place"
        '
        'LblAddress
        '
        Me.LblAddress.AutoSize = True
        Me.LblAddress.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.LblAddress.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.LblAddress.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.LblAddress.Location = New System.Drawing.Point(930, 180)
        Me.LblAddress.Name = "LblAddress"
        Me.LblAddress.Size = New System.Drawing.Size(140, 29)
        Me.LblAddress.TabIndex = 12
        Me.LblAddress.Text = "Address Place"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Label8.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label8.Location = New System.Drawing.Point(481, 444)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(0, 29)
        Me.Label8.TabIndex = 15
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label9.Location = New System.Drawing.Point(372, 443)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(19, 30)
        Me.Label9.TabIndex = 14
        Me.Label9.Text = ":"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label10.Location = New System.Drawing.Point(269, 443)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(99, 30)
        Me.Label10.TabIndex = 13
        Me.Label10.Text = "Keluhan"
        '
        'ListBoxKeluhan
        '
        Me.ListBoxKeluhan.FormattingEnabled = True
        Me.ListBoxKeluhan.ItemHeight = 25
        Me.ListBoxKeluhan.Location = New System.Drawing.Point(277, 487)
        Me.ListBoxKeluhan.Name = "ListBoxKeluhan"
        Me.ListBoxKeluhan.Size = New System.Drawing.Size(447, 179)
        Me.ListBoxKeluhan.TabIndex = 16
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label1.Location = New System.Drawing.Point(256, 240)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(157, 30)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Jenis Kelamin"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label6.Location = New System.Drawing.Point(443, 240)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(19, 30)
        Me.Label6.TabIndex = 7
        Me.Label6.Text = ":"
        '
        'LblJK
        '
        Me.LblJK.AutoSize = True
        Me.LblJK.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.LblJK.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.LblJK.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.LblJK.Location = New System.Drawing.Point(468, 241)
        Me.LblJK.Name = "LblJK"
        Me.LblJK.Size = New System.Drawing.Size(90, 29)
        Me.LblJK.TabIndex = 11
        Me.LblJK.Text = "JK Place"
        '
        'LblBirth
        '
        Me.LblBirth.AutoSize = True
        Me.LblBirth.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.LblBirth.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.LblBirth.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.LblBirth.Location = New System.Drawing.Point(468, 176)
        Me.LblBirth.Name = "LblBirth"
        Me.LblBirth.Size = New System.Drawing.Size(84, 29)
        Me.LblBirth.TabIndex = 19
        Me.LblBirth.Text = "Birthday"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label12.Location = New System.Drawing.Point(443, 175)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(19, 30)
        Me.Label12.TabIndex = 18
        Me.Label12.Text = ":"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label13.Location = New System.Drawing.Point(256, 175)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(152, 30)
        Me.Label13.TabIndex = 17
        Me.Label13.Text = "Tanggal Lahir"
        '
        'LblLayanan
        '
        Me.LblLayanan.AutoSize = True
        Me.LblLayanan.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.LblLayanan.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.LblLayanan.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.LblLayanan.Location = New System.Drawing.Point(930, 240)
        Me.LblLayanan.Name = "LblLayanan"
        Me.LblLayanan.Size = New System.Drawing.Size(88, 29)
        Me.LblLayanan.TabIndex = 22
        Me.LblLayanan.Text = "Layanan"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label14.Location = New System.Drawing.Point(905, 239)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(19, 30)
        Me.Label14.TabIndex = 21
        Me.Label14.Text = ":"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label15.Location = New System.Drawing.Point(718, 239)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(101, 30)
        Me.Label15.TabIndex = 20
        Me.Label15.Text = "Layanan"
        '
        'LblCtnDok
        '
        Me.LblCtnDok.AutoSize = True
        Me.LblCtnDok.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.LblCtnDok.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.LblCtnDok.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.LblCtnDok.Location = New System.Drawing.Point(930, 313)
        Me.LblCtnDok.Name = "LblCtnDok"
        Me.LblCtnDok.Size = New System.Drawing.Size(81, 29)
        Me.LblCtnDok.TabIndex = 25
        Me.LblCtnDok.Text = "Catatan"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label16.Location = New System.Drawing.Point(905, 312)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(19, 30)
        Me.Label16.TabIndex = 24
        Me.Label16.Text = ":"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Franklin Gothic Medium", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label17.Location = New System.Drawing.Point(718, 312)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(172, 30)
        Me.Label17.TabIndex = 23
        Me.Label17.Text = "Catatan Dokter"
        '
        'InfoPasien
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Info
        Me.ClientSize = New System.Drawing.Size(1333, 691)
        Me.Controls.Add(Me.LblCtnDok)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.LblLayanan)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.LblBirth)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.ListBoxKeluhan)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.LblAddress)
        Me.Controls.Add(Me.LblJK)
        Me.Controls.Add(Me.LblNIK)
        Me.Controls.Add(Me.LblName)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Nama)
        Me.Controls.Add(Me.PcbPasien)
        Me.Name = "InfoPasien"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Cetak Info Pasien"
        CType(Me.PcbPasien, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PcbPasien As PictureBox
    Friend WithEvents Nama As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents LblName As Label
    Friend WithEvents LblNIK As Label
    Friend WithEvents LblAddress As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents ListBoxKeluhan As ListBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents LblJK As Label
    Friend WithEvents LblBirth As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents LblLayanan As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents LblCtnDok As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
End Class
